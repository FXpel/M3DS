Pelage François-Xavier


tout a été fait et fonctionne.
difficultés rencontré:
	-lors de la création des roues
	-à comprendre comment bien déplacer la caméra
