Pelage François-Xavier

Doit contenir :
- ce que vous n'avez pas fait (et pourquoi). Précisez explicitement "tout a été fait et fonctionne parfaitement" si c'est le cas.
- difficultés rencontrées.
- commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 

tout à été fait et fonctionne parfaitement.

difficulté rencontré pour bien comprendre le fonctionnement de la fonction separate, surtout savoir quand est-ce que l'on utilise this ou f 