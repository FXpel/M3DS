Pelage François-Xavier

Tout à été fait et fonctionne mise à part la question bonus