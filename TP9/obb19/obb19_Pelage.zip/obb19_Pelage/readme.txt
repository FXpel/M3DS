Pelage François-Xavier

Problème lors de la collisions des deux boites, les deux boîtes disparaissent alors que la collision est détectée. Je n'arrive pas à trouver le problème.
La dernière question n'a pas non plus été faite.

Le reste des question ont été faites.

