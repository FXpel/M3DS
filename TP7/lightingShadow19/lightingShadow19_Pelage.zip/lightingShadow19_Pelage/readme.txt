Pelage François-Xavier




Question 10: fonctionne mais pas évident à voir sur mon pc.

Question 11 non faite

Le reste à été fait correctement
