Pelage François-Xavier

Doit contenir :
- ce que vous n'avez pas fait (et pourquoi). Précisez explicitement "tout a été fait et fonctionne parfaitement" si c'est le cas.
- difficultés rencontrées.
- commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 

Question 8 :
il y a superposition des triangle:
on construit en premier le triangle rouge, puis le triangle vert, le triangle bleu et enfin le triangle cyan.
On peut voir que les triangle se superposent, et pour ne pas avoir d'interpolation des couleurs, on duplique les différents sommets.



